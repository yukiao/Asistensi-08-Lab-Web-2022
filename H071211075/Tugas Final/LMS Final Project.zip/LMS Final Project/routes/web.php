<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AkunController;
use App\Http\Controllers\DosenController;
use App\Http\Controllers\KelasController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\TugasController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\MahasiswaController;
use App\Http\Controllers\MatakuliahController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('dashboard');
});

Route::get('/login', [LoginController::class, 'showLogin']);

//----------------------------------------------VIEW--------------------------------------------------------//
Route::get('/dashboard', [DashboardController::class, 'showDashboard']);
Route::get('/homepage', [DashboardController::class, 'showHomepage']);
Route::get('/matakuliah', [MatakuliahController::class, 'showmatakuliah']);
Route::get('/tambah/matakuliah', [MatakuliahController::class, 'tambahmatakuliah']);
Route::get('/dosen', [DosenController::class, 'showDosen']);
Route::get('/tambah/dosen', [AkunController::class, 'tambahDosen']);
Route::get('/mahasiswa', [MahasiswaController::class, 'showMahasiswa']);
Route::get('/tambah/mahasiswa', [MahasiswaController::class, 'tambahMahasiswa']);

Route::get('/profile', [MahasiswaController::class, 'showProfile']);
Route::get('/kelasku', [KelasController::class, 'showKelas']);
Route::get('/daftarKelas', [KelasController::class, 'showDaftarKelas']);
Route::get('/daftarTugas', [TugasController::class, 'showDaftarTugas']);



//----------------------------------------------STORE-------------------------------------------------------//
Route::post('/tambah/tambahdosen', [AkunController::class, 'tambahDosenBaru']);
Route::post('/tambah/tambahmahasiswa', [AkunController::class, 'tambahMahasiswaBaru']);

Route::post('/addkelas', [KelasController::class, 'store']);
Route::post('/addtugas', [TugasController::class, 'store']);

//----------------------------------------------UPDATE-------------------------------------------------------//
Route::post('/updatekelas', [KelasController::class, 'update']);
Route::post('/updatetugas', [TugasController::class, 'update']);

//----------------------------------------------DELETE-------------------------------------------------------//

