<?php

namespace App\Http\Controllers;

use App\Models\Kelas;
use App\Http\Requests\StoreKelasRequest;
use App\Http\Requests\UpdateKelasRequest;

class KelasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function showKelas()
    {
        $nilai = Kelas::all();
        return view('kelasku', compact('nilai'));
    }
    
    public function showDaftarKelas()
    {
        $nilai = Kelas::all();
        return view('daftarKelas', compact('nilai'));
    }
    public function tambahKelas()
    {
        return view('tambah/kelas');
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
    //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreKelasRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store($request)
    {
        $validatedData = $request->validate([
            // 'Judul' => 'required',
            // 'Tahun' => 'required',
            // 'Pengarang' => 'required',
            // 'Penerbit' => 'required'
        ]);
        Kelas::create($request->all());
        $request->flash('status', 'Kelas berhasil ditambahkan');
        return redirect('/kelasku');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Kelas  $kelas
     * @return \Illuminate\Http\Response
     */
    public function show(Kelas $kelas)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Kelas  $kelas
     * @return \Illuminate\Http\Response
     */
    public function edit(Kelas $kelas)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateKelasRequest  $request
     * @param  \App\Models\Kelas  $kelas
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateKelasRequest $request, Kelas $kelas, $id)
    {
        $data = Kelas::find($id);
        try {
            $data->update($request->all());
            $request->flash('status', 'Kelas berhasil diupdate');
            //code...
        } catch (\Throwable $th) {
            $request->flash('fail', 'Kelas double');

        }
        return redirect('/kelasku');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Kelas  $kelas
     * @return \Illuminate\Http\Response
     */
    public function destroy(Kelas $request, $id)
    {
        $data = Kelas::find($id);
        $data->delete();
        $request->flash('status', 'Data berhasil dihapus');
        return redirect('/kelasku');
    }
}
